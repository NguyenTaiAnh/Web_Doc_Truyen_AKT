<?php $__env->startSection('content'); ?>
    <section id="main-content">
        <section class="wrapper">

            <div class="row">
                <div class="col-lg-12 main-chart">

                    <div class="row mtbox">
                        <div style="margin:0 50px">
                            <a class="btn btn-primary"
                               style="margin-bottom: 10px; float: right"
                               href="<?php echo e(route('category.index')); ?>"
                               role="button">
                                Back
                            </a>

                            <form class="form-horizontal" action="<?php echo e(route('category.update',$category->id)); ?>"method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>

                                <fieldset>
                                    <!-- Form Name -->
                                    <legend>category</legend>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">category Name</label>
                                        <div class="col-md-4">
                                            <input name="name" value="<?php echo e($category->name); ?>" class="form-control input-md" required="" type="text">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Description</label>
                                        <div class="col-md-4">
                                            <textarea name="description" class="form-control input-md" required="" >
                                                <?php echo e($category->description); ?>

                                            </textarea>
                                        </div>
                                    </div>
                                    <!-- Button -->
                                    <div class="form-group">
                                        <label class="col-md-4 control-label"></label>
                                        <div class="col-md-4">
                                            <button id="singlebutton" name="singlebutton" class="btn btn-primary">Update category</button>
                                        </div>
                                    </div>

                                </fieldset>
                            </form>
                        </div>
                    </div><!-- /row mt -->
                </div>
            </div>
        </section>
    </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bai_tap\truyen_chu\resources\views/category/edit.blade.php ENDPATH**/ ?>