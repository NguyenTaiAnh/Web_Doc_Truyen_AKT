<?php $__env->startSection('content'); ?>
    <section id="main-content">
        <section class="wrapper">

            <div class="row">
                <div class="col-lg-12 main-chart">

                    <div class="row mtbox">
                        <div style="margin:0 50px">
                            
                            <form class="form-horizontal" action="<?php echo e(route('chapter.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <fieldset>
                                    <!-- Form Name -->
                                    <legend>chapter <a class="btn btn-primary"
                                                     style="margin-bottom: 10px; float: right"
                                                     href="<?php echo e(route('chapter.index')); ?>"
                                                     role="button">
                                            Back
                                        </a></legend>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Chapter</label>
                                        <div class="col-md-4">
                                            <input name="chap" placeholder="chapter" class="form-control input-md" required="" type="text">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Chapter Name</label>
                                        <div class="col-md-4">
                                            <input name="name" placeholder="chapter name" class="form-control input-md" required="" type="text">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Author</label>
                                        <div class="col-md-4">
                                            <select name="story" class="form-control">
                                                <?php $__currentLoopData = $story; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($sto->id); ?>" ><?php echo e($sto->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Content</label>
                                        <div class="col-md-4">
                                            <textarea name="content" class="form-control input-md" required="" >

                                            </textarea>
                                        </div>
                                    </div>


                                    <!-- Button -->
                                    <div class="form-group">
                                        <label class="col-md-4 control-label"></label>
                                        <div class="col-md-4">
                                            <button id="singlebutton" name="singlebutton" class="btn btn-primary">Add chapter</button>
                                        </div>
                                    </div>

                                </fieldset>
                            </form>
                        </div>
                    </div><!-- /row mt -->
                </div>
            </div>
        </section>
    </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bai_tap\truyen_chu\resources\views/chapter/create.blade.php ENDPATH**/ ?>