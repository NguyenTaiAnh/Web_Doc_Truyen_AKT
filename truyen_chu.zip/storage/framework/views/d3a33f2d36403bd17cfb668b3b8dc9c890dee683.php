<?php echo e($slot); ?>

<?php /**PATH D:\bai_tap\truyen_chu\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>