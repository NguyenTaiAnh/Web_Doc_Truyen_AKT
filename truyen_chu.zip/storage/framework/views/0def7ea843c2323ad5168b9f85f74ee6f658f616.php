<form method="post" action="<?php echo e(route('category.store')); ?>">
    <?php echo csrf_field(); ?>
    nhapten:
    <input type="text" name="name" placeholder="nhap ten">
    <button type="submit" >Submit</button>
</form>
<?php /**PATH D:\bai_tap\truyen_chu\resources\views/create.blade.php ENDPATH**/ ?>