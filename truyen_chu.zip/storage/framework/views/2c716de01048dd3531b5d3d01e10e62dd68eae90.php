<a href="<?php echo e(route('author.index')); ?>">back</a>
<form action="<?php echo e(route('author.show',$author->id)); ?>" >
   <p>name: <?php echo e($author->name); ?></p>
</form>
<?php /**PATH D:\bai_tap\truyen_chu\resources\views/author/show.blade.php ENDPATH**/ ?>