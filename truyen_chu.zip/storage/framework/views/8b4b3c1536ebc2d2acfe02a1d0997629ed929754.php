<form action="<?php echo e(route('category.show',$category->id)); ?>" method="get" enctype="multipart/form-data">

    <?php echo csrf_field(); ?>
    <p>Name: <?php echo e($category->name); ?></p>


</form>
<?php /**PATH D:\bai_tap\truyen_chu\resources\views/category/show.blade.php ENDPATH**/ ?>