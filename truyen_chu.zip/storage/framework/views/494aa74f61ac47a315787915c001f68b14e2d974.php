<?php $__env->startSection('content'); ?>

    <div class="banner">
        <div class="center">
            <div class="text">
                <span></span><span class="type"></span>
            </div>
        </div>
    </div>
    <button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>

    <div class="container">

        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12 col-12 right" style="padding: 0;">
                <div style="background: #ecf0f1;">
                    <div class="title" style="background: #03a9f4;">
                        <p style="font-size: 18px;">Thể loại</p>
                    </div>
                    <!-- =====================================BEGIN CATEGORY============================= -->
                    <div class="row" style="margin: auto;">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-6 col-6" style="text-align: center;line-height: 25px;">
                            <p><a href="<?php echo e(route('theloai',$cate->id)); ?>" class="cls_hover"><?php echo e($cate->name); ?></a></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- ======================================END CATEGORY================================ -->
                </div>
                <div class="title" style="background: #28a745;">
                    <p style="font-size: 18px;">Truyện Mới Cập Nhật</p>
                </div>
                <!-- ==============================NEW STORIES========================================= -->
                <?php $__currentLoopData = $chapter1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($index < 10): ?>
                <div class="row" style="margin: auto;">
                    <div class="col-lg-2 col-md-2 col-sm-2 col-2" style="margin: auto;">
                        <div>

                            <p class="number" style="<?php echo e($index < 3 ? "border: 1px solid #e74c3c;background:  #e74c3c;" : "border: 1px solid black; color: black"); ?>"><?php echo e($index+1); ?></p>
                        </div>
                    </div>
                    <div class="col-lg-10 col-md-10 col-sm-10 col-10" style="padding: 0;">
                        <p><a href="/truyen/<?php echo e($chap->story->id); ?>" class="new_story" style="color: teal; font-weight: 500;"><?php echo e($chap->story->name); ?></a></p>
                        <p><a href="/tacgia/<?php echo e($chap->story->author->id); ?>" class="new_story"><?php echo e($chap->story->author->name); ?></a></p>
                    </div>



                </div>
                    <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- ==============================NEW STORIES========================================= -->

            </div>
            <div class="col-lg-8 col-md-8 col-sm-12 col-12 ">
                <div class="left">


                    <div class="title" style="background:  #009688;">
                        <p style="font-size: 18px;">Truyện Tổng Hợp</p>
                    </div>
                    <div class="container" style="padding: 0px;">
                        <!----------------------------------- Begin all storeis -------------------------- -->

                        <?php $__currentLoopData = $chapter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="row" style="padding: 0 ;margin: 5px 0px;">
                            <div class="col-sm-3 col-3 col-md-3 col-lg-3" style=" padding: 0px;">
                                <div class="nh-thumb nh-thumb--72  mr-3">
                                    <img src="/assets/images/<?php echo e($chap->story->image); ?>" alt="" class="edit_img" width="100">
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-6 col-6" style="margin: auto;">

                                <div>
                                    <p class="name_stories"><a href="<?php echo e(route('truyen',$chap->story->id)); ?>" class="new_story"><i class="fa fa-book"
                                                aria-hidden="true"></i>
                                            <?php echo e($chap['story']['name']); ?></a></p>
                                    <p><a href="<?php echo e(route('tacgia',$chap->story->author->id)); ?>" class="new_story"><i class="fa fa-pencil-square-o"
                                                aria-hidden="true"></i>
                                            <?php echo e($chap['story']['author']['name']); ?></a></p>
                                </div>

                            </div>
                            <div class="col-md-3 col-lg-3 col-3 col-sm-3" style="margin: auto;">
                                <div>

                                    <p class="chapter"><a href="chitiet/<?php echo e(getNew($chap['story_id'])['story']['name']); ?>/<?php echo e(getNew($chap['story_id'])['chap']); ?>" class="new_story">Chương <?php echo e(getNew($chap['story_id'])['chap']); ?></a></p>

                                </div>
                            </div>
                        </div>
                        <hr style="margin: 0px;">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- =================end========================== -->
                        <div>
                        <nav aria-label="...">
                            <ul class="pagination">
                                <?php echo $chapter->links(); ?>


                            </ul>
                        </nav>
                        </div>




                    <!------------------------------------ end all stories ------------------------------->
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bai_tap\truyen_chu\resources\views/TrangChu.blade.php ENDPATH**/ ?>