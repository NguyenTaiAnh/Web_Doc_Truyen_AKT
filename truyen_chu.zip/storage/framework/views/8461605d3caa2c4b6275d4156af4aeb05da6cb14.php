<?php $__env->startSection('content'); ?>
    <button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>
    <div class="container" style="margin-top: 20px;">
        <div class="row">
            <div class="col-md-12 col-sm-12">

                <div style="text-align: center; margin-bottom: 20px;">
                    <h2 style="text-transform: uppercase; text-align: center;"><?php echo e($chapter->story->name); ?> </h2>
                    <p class="chapter-name"><a >Chương <?php echo e($chapter->chap); ?> : <?php echo e($chapter->name); ?></a></p>
                    <hr class="chapter-start">
                    <div>
                        <a href="chitiet/<?php echo e($chapter->story->name); ?>/<?php echo e($chapter->chap-1); ?>" class=" <?php echo e($chapter->chap > 1 ? "btn btn-success btn-chapter-nav" : "btn btn-success btn-chapter-nav disabled"); ?>">Chương Trước</a>

                        <select class="btn btn-success btn-chapter-nav form-control" name="chapter">
                            <?php $__currentLoopData = $totalChapter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($total->story->id === $chapter->story->id): ?>
                            <option value="<?php echo e($total->id); ?>"
                                <?php echo e($total->chap === $chapter->chap ? "selected" : ""); ?>

                            >Chương <?php echo e($total->chap); ?>: <?php echo e($total->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                            <a href="chitiet/<?php echo e($chapter->story->name); ?>/<?php echo e($chapter->chap+1); ?>" class="<?php echo e($chapter->chap+1 > $countChapter->count()  ? "btn btn-success btn-chapter-nav disabled" : "btn btn-success btn-chapter-nav "); ?>">Chương Tiếp</a>

                    </div>
                    <hr class="chapter-start">
                </div>
                <div class="chuong">
                    <p>
                        <?php echo e($chapter->content); ?>

                    </p>
                </div>
                <div style="text-align: center; margin-bottom: 20px;">

                    <hr class="chapter-start">
                    <div>
                        <a href="chitiet/<?php echo e($chapter->story->name); ?>/<?php echo e($chapter->chap-1); ?>" class=" <?php echo e($chapter->chap > 1 ? "btn btn-success btn-chapter-nav" : "btn btn-success btn-chapter-nav disabled"); ?>">Chương Trước</a>
                        <select class="btn btn-success btn-chapter-nav form-control">
                            <?php $__currentLoopData = $totalChapter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($total->story->id === $chapter->story->id): ?>
                                    <option value="<?php echo e($total->id); ?>"
                                        <?php echo e($total->chap === $chapter->chap ? "selected" : ""); ?>

                                    >Chương <?php echo e($total->chap); ?>: <?php echo e($total->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <a href="chitiet/<?php echo e($chapter->story->name); ?>/<?php echo e($chapter->chap+1); ?>" class="btn btn-success btn-chapter-nav ">Chương Tiếp</a>

                    </div>
                    <hr class="chapter-start">
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bai_tap\truyen_chu\resources\views/page/chitiet.blade.php ENDPATH**/ ?>