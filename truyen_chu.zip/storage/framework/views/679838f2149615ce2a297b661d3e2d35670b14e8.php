<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 20px;">
        <div class="row">
            <div class="col-md-8 col-lg-8 col-xs-8 col-sm-12 truyen-main">
                <h2 style="border-bottom:1px solid ;">Kết quả tìm kiếm: <?php echo e($tukhoa); ?></h2>
                Tìm Thấy <?=count($story)?></strong> Nội Dung Cho Từ Khóa: <?=$tukhoa?>
                <!-- --------------------------content---------------------------- -->

                <?php $__currentLoopData = $story; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $chapter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($chap->story->id == $stor->id): ?>
                            <div class="truyen">
                                <div class="row" style="margin: 0;">
                                    <div class="col-md-3 col-sm-3 col-3 " style="padding: 0;">
                                        <img src=" /assets/images/<?php echo e($chap->story->image); ?>" class="img_cate" alt="">
                                    </div>
                                    <div class="col-md-9 col-sm-9 col-9 content">
                                        <p class="name_stories"><a href="<?php echo e(route('truyen',$chap->story->id)); ?>"
                                                                   class="new_story"><i class="fa fa-book"
                                                                                        aria-hidden="true"></i>
                                                <?php echo e($chap->story->name); ?></a></p>

                                        <p><a href="tacgia/<?php echo e($chap->story->author->id); ?>" class="new_story"><i class="fa fa-pencil-square-o"
                                                                   aria-hidden="true"></i> <?php echo e($chap->story->author->name); ?>

                                            </a></p>
                                        <div style="word-break: break-all" class="showhide">
                                            <p class=" content text-less "><?php echo e($chap->story->description); ?></p>
                                            <p class=" content text-more d-none"><?php echo e($chap->story->description); ?></p>
                                        </div>
                                        
                                        <p>Chương: <a href="chitiet/<?php echo e(getNew($chap['story_id'])['story']['name']); ?>/<?php echo e(getNew($chap['story_id'])['chap']); ?>" class="new_story"><?php echo e(getNew($chap['story_id'])['chap']); ?>

                                                : <?php echo e(getNew($chap['story_id'])['name']); ?></a></p>

                                    </div>
                                </div>
                            </div>
                            <hr>

                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- -------------------------- end-content---------------------------- -->

                <?php echo $chapter->links(); ?>


            </div>
            <!-- -------------------- end---------------- -->
            <div class="col-md-4 col-lg-4 col-xs-4 col-sm-12">
                <div style="background: #ecf0f1;">
                    <div class="title" style="background: #03a9f4;">
                        <p style="font-size: 18px;">Thể loại</p>
                    </div>
                    <!-- =====================================BEGIN CATEGORY============================= -->
                    <div class="row" style="margin: auto;">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-lg-6 col-6" style="text-align: center;line-height: 25px;">
                                <p><a href="<?php echo e(route('theloai',$cate->id)); ?>" class="cls_hover"><?php echo e($cate->name); ?></a></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- ======================================END CATEGORY================================ -->
                </div>
                <div class="title" style="background: #28a745;">
                    <p style="font-size: 18px;">Truyện Mới Cập Nhật</p>
                </div>
                <!-- ==============================NEW STORIES========================================= -->
                <div class="row" style="margin: auto;">
                    <?php $__currentLoopData = $chapter1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($index <10): ?>
                            <div class="col-lg-2 col-md-2 col-sm-2 col-2" style="margin: auto;">
                                <div>
                                    <p class="number" style="<?php echo e($index < 3 ? "border: 1px solid #e74c3c;background:  #e74c3c;" : "border: 1px solid black; color: black"); ?>"><?php echo e($index+1); ?></p>
                                </div>
                            </div>
                            <div class="col-lg-10 col-md-10 col-sm-10 col-10" style="padding: 0;">
                                <p><a href="/truyen/<?php echo e($chap->story->id); ?>" class="new_story" style="color: teal; font-weight: 500;"><?php echo e($chap->story->name); ?></a></p>
                                <p><a href="/tacgia/<?php echo e($chap->story->author->id); ?>" class="new_story"><?php echo e($chap->story->author->name); ?></a></p>
                            </div>
                            <!-- =================end========================== -->
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
                <!-- ==============================NEW STORIES========================================= -->

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
    <script !src="">
        const thDescription = document.querySelectorAll('.showhide');



        thDescription.forEach((item, index) => {
            const textLess = item.querySelector('.text-less');
            const textMore = item.querySelector('.text-more');
            const btnMore = document.createElement('span');

            btnMore.setAttribute('class', 'btn btn-primary')
            btnMore.innerHTML  = "Show"
            btnMore.style.cursor = 'pointer'

            if(textLess.textContent.length > 50){
                textLess.innerHTML = textLess.textContent.substr(0, 50) + '...'
                item.appendChild(btnMore)
            }
            btnMore.onclick = function () {
                textMore.classList.toggle('d-none')
                textLess.classList.toggle('d-none')

                if(textLess.getAttribute('class').includes('d-none')){
                    btnMore.innerHTML  = "Hide"
                    btnMore.classList.add('btn-danger')
                } else {
                    btnMore.innerHTML  = "Show"
                    btnMore.classList.remove('btn-danger')

                }
            }
        })


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bai_tap\truyen_chu\resources\views/page/timkiem.blade.php ENDPATH**/ ?>