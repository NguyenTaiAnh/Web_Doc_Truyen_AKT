<form action="<?php echo e(route('category.update',$category->id)); ?>" method="post" >
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    name
    <input type="text" name="name" placeholder="nhap ten">
    <button >Submit</button>
</form>
<?php /**PATH D:\bai_tap\truyen_chu\resources\views/edit.blade.php ENDPATH**/ ?>