<form action="<?php echo e(route('category.show',$category->id_category)); ?>" method="get" enctype="multipart/form-data">

    <?php echo csrf_field(); ?>
    <p>Name: <?php echo e($category->name); ?></p>
    

</form>
<?php /**PATH D:\bai_tap\truyen_chu\resources\views/show.blade.php ENDPATH**/ ?>