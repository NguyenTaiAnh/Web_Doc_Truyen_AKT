<?php $__env->startSection('content'); ?>
    <section id="main-content">
        <section class="wrapper">

            <div class="row">
                <div class="col-lg-12 main-chart">

                    <div class="row mtbox">
                        <div style="margin:0 50px">
                            <form class="form-horizontal" action="<?php echo e(route('story.update', $story['id'])); ?> " enctype="multipart/form-data"
                                  method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <?php echo method_field('PATCH'); ?>
                                <fieldset>
                                    <!-- Form Name -->
                                    <legend>story <a class="btn btn-primary" style="margin-bottom: 10px; float: right"
                                                     href="<?php echo e(route('story.index')); ?>" role="button"> Back </a></legend>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">story Name</label>
                                        <div class="col-md-4">
                                            <input name="name" placeholder="story name" class="form-control input-md"
                                                   required="" type="text" value="<?php echo e($story->name); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Category</label>
                                        <table>
                                            <tr>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <th>
                                                        <input type="checkbox" name="category_id[]"
                                                               value="<?php echo e($category['id']); ?>"
                                                            <?php echo e(in_array($category['id'], $oldCategory) ? 'checked' : ''); ?>>
                                                        <label for=""> <?php echo e($category['name']); ?></label><br>
                                                    </th>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Author</label>
                                        <div class="col-md-4">
                                            <select name="author_id" class="form-control">
                                                <?php $__currentLoopData = $author; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $au): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($au->id); ?>"
                                                        <?php echo e($au->id == $story->author_id ? 'selected' : ''); ?>><?php echo e($au->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div>
                                            <?php echo e($story->author->name); ?>


                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Status</label>
                                        <div class="col-md-4">
                                            <select name="status_id" class="form-control">
                                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($sta->id); ?>"
                                                        <?php echo e($sta->id == $story->status_id ? 'selected' : ''); ?>>
                                                        <?php echo e($sta->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <di>
                                            <?php echo e($story->status->name); ?>

                                        </di>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Description</label>
                                        <div class="col-md-4">
                                            <textarea name="description" class="form-control input-md" required="">
                                            <?php echo e($story->description); ?>

                                            </textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Image</label>
                                        <div class="col-md-4">
                                            <input type="file" name="image" class="form-control-file">
                                            <img src="/assets/images/<?php echo e($story->image); ?>" width="100">
                                        </div>
                                    </div>

                                    <!-- Button -->
                                    <div class="form-group">
                                        <label class="col-md-4 control-label"></label>
                                        <div class="col-md-4">
                                            <button id="singlebutton" name="singlebutton" class="btn btn-primary">Update
                                                Story
                                            </button>
                                        </div>
                                    </div>

                                </fieldset>

                            </form>
                        </div>
                    </div><!-- /row mt -->
                </div>
            </div>
        </section>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bai_tap\truyen_chu\resources\views/story/update.blade.php ENDPATH**/ ?>