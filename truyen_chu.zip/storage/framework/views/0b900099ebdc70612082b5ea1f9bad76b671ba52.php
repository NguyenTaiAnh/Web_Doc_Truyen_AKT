<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 20px;">
        <input type="hidden" name="<?php echo e($chapter->story->id); ?>" id="story">
        <div class="row">
            <div class="col-md-8 col-lg-8 col-xs-8 col-sm-12 truyen-main">
                <div class="row">
                    <div class="col-md-4 col-lg-4 col-sm-12 col-12" style="padding: 0; margin-bottom: 20px;">
                        <img src=" /assets/images/<?php echo e($chapter->story->image); ?>" width="100%" alt="">
                    </div>
                    <div class="col-md-8 col-lg-8 col-sm-12 col-12">
                        <div style="display: block; margin: auto;">
                            <div style="line-height: 2;">
                                <h3 style="text-transform: uppercase; font-weight: bold;"><?php echo e($chapter->story->name); ?></h3>
                                <p class="str-name">Tác giả: <a href="<?php echo e(route('tacgia', $chapter->story->author->id)); ?>"
                                        style="text-transform: capitalize;"><?php echo e($chapter->story->author->name); ?></a>
                                </p>
                                <p class="str-name">Thể loại:

                                    <?php $__currentLoopData = getCategory($chapter->story->category_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <a href="<?php echo e(route('theloai', $name->id)); ?>" style="text-transform: capitalize;">
                                            <?php echo e($name['name']); ?>

                                        </a>

                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p>
                                <p>Trạng thái: <span
                                        style="text-transform: capitalize;"><?php echo e($chapter->story->status->name); ?></span></p>
                                <p>Độ dài: <span><?php echo e($count); ?></span></p>

                            </div>
                            <div style=" margin-bottom: 10px;">



                                <?php if(Route::has('login')): ?>
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php if(!$check): ?>
                                        <form action="<?php echo e(route('theodoi')); ?>" method="post">
                                            <input type="hidden" name="story_id" value="<?php echo e($chapter->story->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="follow" type="submit"><i class="fa fa-bookmark" aria-hidden="true"></i>

                                                Theo Dõi</button>
                                        </form>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>











                                <ul class="btn_gt">
                                    <li class="">
                                        <a class="" href="<?php echo e(route('truyen', $chapter->story->id)); ?>#gioithieu">Giới
                                            Thiệu</a>
                                    </li>
                                    <li
                                        style="border: 1px solid #5cabb8;
                                                                                                                                                                                                                                                                                                                                            background: #5cabb8;">
                                        <a href="<?php echo e(route('truyen', $chapter->story->id)); ?>/#danhsach">Danh Sách
                                            Chương</a>
                                    </li>
                                </ul>
                                <a href="/chitiet/<?php echo e($chapter->story->name); ?>/<?php echo e($chapter->chap); ?>" class="btn_story">Đọc
                                    Truyện</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="gioithieu">
                    <h5 class="title-name">Giới thiệu truyện <span
                            style="text-transform: capitalize; font-weight: bold; "><?php echo e($chapter->story->name); ?> </span>
                    </h5>
                    <hr style="margin-top: 0;">

                    <p style="line-height: 2;"><?php echo e($chapter->story->description); ?></p>
                </div>
                <div id="danhsach">
                    <h5 class="title-name">Danh sách chương</h5>
                    <hr style="margin-top: 0;">
                    <div class="container">
                        <div class="row">
                            <?php $__currentLoopData = $allChapter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-sm-12 col-12">
                                    <ul class="detail">
                                        <li>
                                            <a href="chitiet/<?php echo e($chap->story->name); ?>/<?php echo e($chap->chap); ?>">Chương
                                                <?php echo e($chap->chap); ?>

                                                : <?php echo e($chap->name); ?> </a>
                                        </li>

                                    </ul>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

            </div>
            <!-- -------------------- end---------------- -->
            <div class="col-md-4 col-lg-4 col-xs-4 col-sm-12">
                <div style="background: #ecf0f1;">
                    <div class="title" style="background: #03a9f4;">
                        <p style="font-size: 18px;">Thể loại</p>
                    </div>
                    <!-- =====================================BEGIN CATEGORY============================= -->
                    <div class="row" style="margin: auto;">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-lg-6 col-6" style="text-align: center;line-height: 25px;">
                                <p><a href="<?php echo e(route('theloai', $cate->id)); ?>" class="cls_hover"><?php echo e($cate->name); ?></a></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- ======================================END CATEGORY================================ -->
                </div>
                <div class="title" style="background: #28a745;">
                    <p style="font-size: 18px;">Truyện Mới Cập Nhật</p>
                </div>
                <!-- ==============================NEW STORIES========================================= -->
                <div class="row" style="margin: auto;">
                    <?php $__currentLoopData = $totalChapter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($index < 10): ?>
                            <div class="col-lg-2 col-md-2 col-sm-2 col-2" style="margin: auto;">
                                <div>
                                    <p class="number"
                                        style="<?php echo e($index < 3 ? 'border: 1px solid #e74c3c;background:  #e74c3c;' : 'border: 1px solid black; color: black'); ?>">
                                        <?php echo e($index + 1); ?>

                                    </p>
                                </div>
                            </div>
                            <div class="col-lg-10 col-md-10 col-sm-10 col-10" style="padding: 0;">
                                <p><a href="/truyen/<?php echo e($chap->story->id); ?>" class="new_story"
                                        style="color: teal; font-weight: 500;"><?php echo e($chap->story->name); ?></a></p>
                                <p><a href="/tacgia/<?php echo e($chap->story->author->id); ?>"
                                        class="new_story"><?php echo e($chap->story->author->name); ?></a></p>
                            </div>
                            <!-- =================end========================== -->
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- =================end========================== -->


                </div>
                <!-- ==============================NEW STORIES========================================= -->

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bai_tap\truyen_chu\resources\views/page/truyen.blade.php ENDPATH**/ ?>