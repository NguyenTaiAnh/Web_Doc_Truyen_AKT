<?php $__env->startSection('content'); ?>
    <section id="main-content">
        <section class="wrapper">

            <div class="row">
                <div class="col-lg-12 main-chart">

                    <div class="row mtbox" style="margin: 0px">

                        <div style="margin: 10px">
                            <h2>Category</h2>

                            <a class="btn btn-primary"
                               style="margin-bottom: 10px; float: right"
                               href="<?php echo e(route('category.create')); ?>"
                               role="button">
                                Add new
                            </a>


                            <table id="example" class="table table-striped table-bordered" style="width:100%">
                                <thead>
                                <tr>

                                    <th scope="col">ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Options</th>

                                </tr>
                                </thead>

                                <tbody>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $au): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <th scope="row"><?php echo e($au->id); ?></th>
                                        <th><?php echo e($au->name); ?></th>
                                        <th><?php echo e($au->description); ?></th>
                                        <th>
                                            <form action="<?php echo e(route('category.destroy',$au->id)); ?>" method="post" >
                                                <?php echo csrf_field(); ?>
                                                <a type="button" class="btn btn-info" href="<?php echo e(route('category.edit',$au->id)); ?>">Update</a>

                                                <a type="button" class="btn btn-success" href="<?php echo e(route('category.show',$au->id)); ?>">Detail</a>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-danger">Delete</button>

                                            </form>
                                        </th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo $category->links(); ?>


                        </div>


                    </div><!-- /row mt -->
                </div>
            </div>
        </section>
    </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bai_tap\truyen_chu\resources\views/category/index.blade.php ENDPATH**/ ?>