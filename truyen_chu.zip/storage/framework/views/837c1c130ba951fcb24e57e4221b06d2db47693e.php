<?php $__env->startSection('header'); ?>
<header>
    <div class="container div_header">
        <nav class="navbar navbar-expand-lg navbar-light ">
            <a class="navbar-brand" href="/" style="color: white;">AKT</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="/">Trang chủ <span class="sr-only">(current)</span></a>
                    </li>

                    <!-- <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle menu-style" href="#" id="navbarDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Thể Loại
                      </a>
                    </li> -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                           aria-haspopup="true" aria-expanded="false">
                            Thể Loại
                        </a>
                        <div class="dropdown-menu" style="width: 600px;" aria-labelledby="navbarDropdown">
                            <div class="container">
                                <div class="row">
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <a class="dropdown-item" href="<?php echo e(route('theloai',$cate->id)); ?>"><?php echo e($cate->name); ?></a>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                           aria-haspopup="true" aria-expanded="false">
                            Danh mục
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="/danhmuc">Truyện Đã Hoàn Thành</a>
                            <a class="dropdown-item" href="danhmuc.html">Truyện Mới</a>
                            <a class="dropdown-item" href="danhmuc.html">Truyện Mới Cập Nhật</a>

                        </div>
                    </li>

                </ul>

                <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-5" type="search" placeholder="Tên truyện hoặc tên tác giả"
                           aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>

                <ul class="navbar-nav ml-auto">
                    <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->role == 1): ?>
                    <li class="nav-item">
                        <a href="/admin" class="nav-link">Admin panel</a>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                           aria-haspopup="true" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">

                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>

                    <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">Đăng Nhập</a>
                    </li>

                    <?php if(Route::has('register')): ?>
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>">Đăng Ký</a>
                    </li>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php endif; ?>
                    
                        
                        
                    
                        
                        
                    
                        
                        
                    
                        
                        
                </ul>
            </div>

        </nav>
    </div>
</header>
<?php echo $__env->yieldContent('chitiet'); ?>
<?php echo $__env->yieldContent('taikhoan'); ?>
<?php echo $__env->yieldContent('tacgia'); ?>
<?php echo $__env->yieldContent('danhmuc'); ?>
<?php echo $__env->yieldContent('theloai'); ?>
<?php echo $__env->yieldContent('truyen'); ?>
<?php echo $__env->yieldContent('dangnhap'); ?>
<?php echo $__env->yieldContent('dangky'); ?>
<?php echo $__env->yieldContent('home'); ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\bai_tap\truyen_chu\resources\views/header.blade.php ENDPATH**/ ?>