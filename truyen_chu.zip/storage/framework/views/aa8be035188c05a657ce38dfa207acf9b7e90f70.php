<footer class="site-footer" style="    position: fixed;
      width: 100%;
      bottom: 0;
      z-index:0">
    <div class="text-center">
        2020-ATK-Truyền Kỳ
        <a href="index.html#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>
<?php /**PATH D:\bai_tap\truyen_chu\resources\views/admin/footer.blade.php ENDPATH**/ ?>